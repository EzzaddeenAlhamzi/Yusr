# YUSR P1.4 API Integration — Reports Package MANIFEST

| Field | Value |
|-------|-------|
| Package | `YUSR_P1_4_API_INTEGRATION_REPORTS.zip` |
| Nature | **Reports-only** — audit docs + sanitized EMA media; **no app source** |
| PR | https://github.com/EzzaddeenAlhamzi/Yusr/pull/8 |
| HEAD | `5e450229f8a14d0eacf5f62e69b73b325ec3afdc` |
| Merge | **DO NOT MERGE** — awaiting PO |
| Date (UTC) | 2026-11-19 |

## Exclusions / hygiene

- **Excluded:** `media/p1.4/p14_13_el_link_code.png` — A9 media-hygiene residual (cleartext 6-digit linking code on screen). Documented in `P1_4_A9.md` / Arabic PO summary; EL generate-code journey still attested via API JSONL + other EL profile media.
- Logs included are pre-sanitized (`[REDACTED]` tokens); prefs snapshots contain lab URL only.
- **Not included:** application source code; PR #6 / `:8000` / YOGC materials.
- Mislabel note: `p14_11_el_home_honesty.png` is a login form (A9); real EL advanced home honesty evidence is `p14_11_el_adv_home.png`.

## ZIP entries

| Path | Description |
|------|-------------|
| `MANIFEST.md` | This English manifest — every ZIP entry with a short description. |
| `SHA256SUMS.txt` | SHA-256 checksums of all included content files (relative paths). |
| `docs/audit/p1.4/P1_4_A8.md` | Independent A8 security review — PASS WITH CONDITIONS. |
| `docs/audit/p1.4/P1_4_A9.md` | Independent A9 QA review — PASS WITH CONDITIONS. |
| `docs/audit/p1.4/P1_4_API_INTEGRATION_AUDIT.md` | Supporting API integration audit notes. |
| `docs/audit/p1.4/P1_4_API_INTEGRATION_MATRIX.md` | ApiService × legacy/REST × Laravel integration matrix. |
| `docs/audit/p1.4/P1_4_EMA.md` | Final comprehensive EMA at tip 5e450229 (device + suites). |
| `docs/audit/p1.4/P1_4_FUNCTIONALITY_MATRIX.md` | Flutter UI × API functionality matrix (screen statuses). |
| `docs/audit/p1.4/P1_4_IMPL.md` | Implementation notes, follow-up fixes, deferred list. |
| `docs/audit/p1.4/P1_4_PO_SUMMARY_AR.md` | Arabic product-owner final summary (counts + gate status). |
| `docs/audit/p1.4/P1_4_PROGRESS_MATRIX.md` | Implementation progress matrix (units A–I). |
| `media/p1.4/p14_00_boot.png` | EMA device screenshot evidence (p14_00_boot.png). |
| `media/p1.4/p14_01_after_logout_cold.png` | EMA device screenshot evidence (p14_01_after_logout_cold.png). |
| `media/p1.4/p14_01_cg_blank.png` | EMA device screenshot evidence (p14_01_cg_blank.png). |
| `media/p1.4/p14_01_cg_filled.png` | EMA device screenshot evidence (p14_01_cg_filled.png). |
| `media/p1.4/p14_01_cg_home.png` | EMA device screenshot evidence (p14_01_cg_home.png). |
| `media/p1.4/p14_01_cg_restored.png` | EMA device screenshot evidence (p14_01_cg_restored.png). |
| `media/p1.4/p14_02_after_el_logout_cold.png` | EMA device screenshot evidence (p14_02_after_el_logout_cold.png). |
| `media/p1.4/p14_02_after_logout.png` | EMA device screenshot evidence (p14_02_after_logout.png). |
| `media/p1.4/p14_02_reopen_auth.png` | EMA device screenshot evidence (p14_02_reopen_auth.png). |
| `media/p1.4/p14_03_el_blank.png` | EMA device screenshot evidence (p14_03_el_blank.png). |
| `media/p1.4/p14_03_el_filled.png` | EMA device screenshot evidence (p14_03_el_filled.png). |
| `media/p1.4/p14_03_el_home.png` | EMA device screenshot evidence (p14_03_el_home.png). |
| `media/p1.4/p14_03_el_restored.png` | EMA device screenshot evidence (p14_03_el_restored.png). |
| `media/p1.4/p14_04_cg2_home.png` | EMA device screenshot evidence (p14_04_cg2_home.png). |
| `media/p1.4/p14_04_cg_after_el.png` | EMA device screenshot evidence (p14_04_cg_after_el.png). |
| `media/p1.4/p14_04_el2_home.png` | EMA device screenshot evidence (p14_04_el2_home.png). |
| `media/p1.4/p14_04_el_after_cg.png` | EMA device screenshot evidence (p14_04_el_after_cg.png). |
| `media/p1.4/p14_05_bad_password.png` | EMA device screenshot evidence (p14_05_bad_password.png). |
| `media/p1.4/p14_05_bad_password_blank.png` | EMA device screenshot evidence (p14_05_bad_password_blank.png). |
| `media/p1.4/p14_05_bad_password_filled.png` | EMA device screenshot evidence (p14_05_bad_password_filled.png). |
| `media/p1.4/p14_05_bad_password_t0.png` | EMA device screenshot evidence (p14_05_bad_password_t0.png). |
| `media/p1.4/p14_05_bad_password_t1.png` | EMA device screenshot evidence (p14_05_bad_password_t1.png). |
| `media/p1.4/p14_05_bad_password_t10.png` | EMA device screenshot evidence (p14_05_bad_password_t10.png). |
| `media/p1.4/p14_05_bad_password_t11.png` | EMA device screenshot evidence (p14_05_bad_password_t11.png). |
| `media/p1.4/p14_05_bad_password_t12.png` | EMA device screenshot evidence (p14_05_bad_password_t12.png). |
| `media/p1.4/p14_05_bad_password_t2.png` | EMA device screenshot evidence (p14_05_bad_password_t2.png). |
| `media/p1.4/p14_05_bad_password_t3.png` | EMA device screenshot evidence (p14_05_bad_password_t3.png). |
| `media/p1.4/p14_05_bad_password_t4.png` | EMA device screenshot evidence (p14_05_bad_password_t4.png). |
| `media/p1.4/p14_05_bad_password_t5.png` | EMA device screenshot evidence (p14_05_bad_password_t5.png). |
| `media/p1.4/p14_05_bad_password_t6.png` | EMA device screenshot evidence (p14_05_bad_password_t6.png). |
| `media/p1.4/p14_05_bad_password_t7.png` | EMA device screenshot evidence (p14_05_bad_password_t7.png). |
| `media/p1.4/p14_05_bad_password_t8.png` | EMA device screenshot evidence (p14_05_bad_password_t8.png). |
| `media/p1.4/p14_05_bad_password_t9.png` | EMA device screenshot evidence (p14_05_bad_password_t9.png). |
| `media/p1.4/p14_05_network_error.png` | EMA device screenshot evidence (p14_05_network_error.png). |
| `media/p1.4/p14_05_network_filled.png` | EMA device screenshot evidence (p14_05_network_filled.png). |
| `media/p1.4/p14_05_network_wait_0.png` | EMA device screenshot evidence (p14_05_network_wait_0.png). |
| `media/p1.4/p14_05_network_wait_10.png` | EMA device screenshot evidence (p14_05_network_wait_10.png). |
| `media/p1.4/p14_05_network_wait_12.png` | EMA device screenshot evidence (p14_05_network_wait_12.png). |
| `media/p1.4/p14_05_network_wait_14.png` | EMA device screenshot evidence (p14_05_network_wait_14.png). |
| `media/p1.4/p14_05_network_wait_16.png` | EMA device screenshot evidence (p14_05_network_wait_16.png). |
| `media/p1.4/p14_05_network_wait_2.png` | EMA device screenshot evidence (p14_05_network_wait_2.png). |
| `media/p1.4/p14_05_network_wait_4.png` | EMA device screenshot evidence (p14_05_network_wait_4.png). |
| `media/p1.4/p14_05_network_wait_6.png` | EMA device screenshot evidence (p14_05_network_wait_6.png). |
| `media/p1.4/p14_05_network_wait_8.png` | EMA device screenshot evidence (p14_05_network_wait_8.png). |
| `media/p1.4/p14_06_offline_while_token.png` | EMA device screenshot evidence (p14_06_offline_while_token.png). |
| `media/p1.4/p14_06_reconnect_restored.png` | EMA device screenshot evidence (p14_06_reconnect_restored.png). |
| `media/p1.4/p14_06c_after_no_bearer_probe.png` | EMA device screenshot evidence (p14_06c_after_no_bearer_probe.png). |
| `media/p1.4/p14_06c_cg_before_revoke_probe.png` | EMA device screenshot evidence (p14_06c_cg_before_revoke_probe.png). |
| `media/p1.4/p14_07_sos_cg_home.png` | EMA device screenshot evidence (p14_07_sos_cg_home.png). |
| `media/p1.4/p14_07_sos_el_home.png` | EMA device screenshot evidence (p14_07_sos_el_home.png). |
| `media/p1.4/p14_08_cg_home_honesty.png` | EMA device screenshot evidence (p14_08_cg_home_honesty.png). |
| `media/p1.4/p14_09_cg_profile.png` | EMA device screenshot evidence (p14_09_cg_profile.png). |
| `media/p1.4/p14_09_cg_settings.png` | EMA device screenshot evidence (p14_09_cg_settings.png). |
| `media/p1.4/p14_10_cg_link.png` | EMA device screenshot evidence (p14_10_cg_link.png). |
| `media/p1.4/p14_11_el_adv_home.png` | EMA device screenshot evidence (p14_11_el_adv_home.png). |
| `media/p1.4/p14_11_el_home_honesty.png` | EMA device screenshot evidence (p14_11_el_home_honesty.png). |
| `media/p1.4/p14_12_el_profile.png` | EMA device screenshot evidence (p14_12_el_profile.png). |
| `media/p1.4/p14_14_reg_cg_login_home.png` | EMA device screenshot evidence (p14_14_reg_cg_login_home.png). |
| `media/p1.4/p14_15_reg_el_login_home.png` | EMA device screenshot evidence (p14_15_reg_el_login_home.png). |
| `media/p1.4/p14_api_live_sanitized.jsonl` | Sanitized live API probe log (tokens/linking codes redacted). |
| `media/p1.4/p14_el_adv_for_logout.png` | EMA device screenshot evidence (p14_el_adv_for_logout.png). |
| `media/p1.4/p14_el_logout_dialog.png` | EMA device screenshot evidence (p14_el_logout_dialog.png). |
| `media/p1.4/p14_el_profile_scrolled.png` | EMA device screenshot evidence (p14_el_profile_scrolled.png). |
| `media/p1.4/p14_head_match.txt` | HEAD match attestation for required tip. |
| `media/p1.4/p14_logcat_sanitized.txt` | Sanitized logcat excerpt (no OVERFLOWED; secrets redacted). |
| `media/p1.4/p14_logout_dialog.png` | EMA device screenshot evidence (p14_logout_dialog.png). |
| `media/p1.4/p14_logout_dialog_spot.png` | EMA device screenshot evidence (p14_logout_dialog_spot.png). |
| `media/p1.4/p14_now_state.png` | EMA device screenshot evidence (p14_now_state.png). |
| `media/p1.4/p14_prefs_mid_switch.xml` | Android SharedPreferences snapshot (lab URL only; no tokens). |
| `media/p1.4/p14_prefs_snapshot.xml` | Android SharedPreferences snapshot (lab URL only; no tokens). |
| `media/p1.4/p14_spot_choose_mode.png` | EMA device screenshot evidence (p14_spot_choose_mode.png). |
| `media/p1.4/p14_spot_no_who.png` | EMA device screenshot evidence (p14_spot_no_who.png). |
| `media/p1.4/p14_spot_who.png` | EMA device screenshot evidence (p14_spot_who.png). |
| `media/p1.4/p14_suite_summary.txt` | Suite EXIT summary (phpunit/flutter analyze/test). |
| `media/p1.4/p14_ui_ids.txt` | Synthetic lab UI IDs (no real secrets). |
| `media/p1.4/p14_ui_results.txt` | Per-scenario UI/API result flags from EMA harness. |
| `media/p1.4/p14_uidump_bad_password.xml` | UI Automator dump for wrong-password journey. |

**Entry count:** 88 (including MANIFEST.md + SHA256SUMS.txt).

## Gate one-liner

P1.4 COMPLETE WITH CONDITIONS @ `5e450229` — A8/A9 PASS WITH CONDITIONS; analyze FAIL; awaiting PO; **DO NOT MERGE**.

