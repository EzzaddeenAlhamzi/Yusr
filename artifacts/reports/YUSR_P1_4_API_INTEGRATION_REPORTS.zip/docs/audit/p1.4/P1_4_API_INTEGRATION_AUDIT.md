---
cursor:
  subagentId: "bc-0ebcf7d2-6be8-572a-9964-d43d2cb6b13a"
---

# P1.4 — API Integration Audit (Laravel ↔ Flutter ApiService)

**Scope:** `/agent/repos/Yusr/backend/routes/api.php`, all `App\Http\Controllers\Api\*`, `LegacyBridgeController`, Flutter `lib/core/services/api_service.dart`, plus profile forms.

**Client path:** Flutter talks **only** to `POST /api/legacy` (action JSON body + optional Bearer). REST routes mirror the same controllers but are unused by the app.

**AuthN:** `legacy.auth` → public for `ping|register_*|login_*|forgot_password`; else Sanctum. REST uses `auth:sanctum` except public auth/ping.

**AuthZ:** Controllers + `YusrAccess` / Gates (ownership by linked `Eldery_ID`).

**Legend:** WORKING | PARTIAL | BROKEN | MOCK ONLY | NOT IMPLEMENTED | DEFERRED

---

## 1. REST routes (`backend/routes/api.php`)

| Method | Path | Controller | AuthN/AuthZ | Request fields | Response shape | DB / models | Class |
|--------|------|------------|-------------|----------------|----------------|-------------|-------|
| GET\|POST | `/api/ping` | Closure | Public | — | `status, message, database, framework` | config only | WORKING |
| POST | `/api/auth/caregiver/register` | `AuthController::registerCaregiver` | Public | `C_Name, C_PhonNumber, C_Relationship, C_Email, C_Password` | `status, message, role, token, caregiver{…}` | `caregivers`, Sanctum `personal_access_tokens` | WORKING |
| POST | `/api/auth/caregiver/login` | `AuthController::loginCaregiver` | Public | `C_PhonNumber` / `identifier` / `C_Email`, `C_Password` | same + `error_type` on fail | `caregivers`, `elderly` (role check), tokens | WORKING |
| POST | `/api/auth/elderly/register` | `AuthController::registerElderly` | Public | `E_Name, E_sex, E_PhonNumber, E_Email, E_Password` | `status, message, role, token, elderly{…}` | `elderly`, tokens | WORKING |
| POST | `/api/auth/elderly/login` | `AuthController::loginElderly` | Public | `E_PhonNumber` / `identifier` / `E_Email`, `E_Password` | same + `error_type` | `elderly`, `caregivers`, tokens | WORKING |
| POST | `/api/auth/forgot-password` | `AuthController::forgotPassword` | Public | `email` \| `C_Email` \| `E_Email` | success/error `status, message` — **no email/token issued** | read `caregivers`/`elderly` only | **MOCK ONLY** |
| GET\|POST | `/api/auth/me` | `AuthController::me` | Sanctum | — | `status, role, caregiver\|elderly` | actor model | WORKING |
| POST | `/api/auth/logout` | `AuthController::logout` | Sanctum | — | `status, message` | revoke tokens | WORKING |
| GET | `/api/caregiver/{id}` | `CaregiverController::show` | Sanctum + Gate view | path `id` | `status, data` (model, password hidden) | `caregivers` | WORKING |
| PUT\|POST | `/api/caregiver/{id?}` | `CaregiverController::update` | Sanctum + Gate update (self CG) | `C_Name, C_PhonNumber, C_Relationship, C_Email, C_Password?`; **Eldery_ID ignored** | `status, message, data` | `caregivers` | WORKING |
| POST | `/api/elderly/linking-code` | `ElderlyController::generateLinkingCode` | Sanctum; elderly-only | (actor self) | `status, message, data{linking_code, expires_at, expires_in_seconds}` | `elderly_linking_codes` | WORKING |
| POST | `/api/elderly/link` | `ElderlyController::linkCaregiver` | Sanctum; caregiver-only; code required | `linking_code`/`code`; optional `Caregivers_ID` (must be self); **direct Eldery_ID alone → 403** | `status, message, caregiver, elderly` | `caregivers`, `elderly`, linking + attempt tables | WORKING |
| GET | `/api/elderly/{id}` | `ElderlyController::show` | Sanctum + Gate view | path `id` | `status, data` (+ nested `caregiver` on self-view) | `elderly`, `caregivers` | WORKING |
| PUT\|POST | `/api/elderly/{id?}` | `ElderlyController::update` | Sanctum + Gate; password elderly-self only | `E_Name, E_sex, E_PhonNumber, E_Email, E_Password?` | `status, message, data` | `elderly` | WORKING |
| GET | `/api/medications` | `MedicationController::index` | Sanctum + elderly scope | `Elderly_ID`/`Eldery_ID` optional | `status, data[]` | `medications` | WORKING |
| POST | `/api/medications` | `MedicationController::store` | Sanctum + gate elderly | `M_Name, M_much, M_RepatTime, Elderly_ID?` | `status, message, data` (201) | `medications` | WORKING |
| PUT\|POST | `/api/medications/{id?}` | `MedicationController::update` | Sanctum + ownership | `Medicayion_ID` or path; `M_Name, M_much, M_RepatTime` | `status, message, data` | `medications` | WORKING |
| DELETE\|POST | `/api/medications/{id?}/delete` | `MedicationController::destroy` | Sanctum + ownership | `Medicayion_ID` or path | `status, message` | `medications` | WORKING |
| GET | `/api/appointments` | `AppointmentController::index` | Sanctum + scope | `Elderly_ID?` | `status, data[]` | `appointments` | WORKING |
| POST | `/api/appointments` | `AppointmentController::store` | Sanctum + gate | `A_DateType, A_Date, A_Time, A_Location, A_Note, Elderly_ID?` | `status, message, data` (201) | `appointments` | WORKING |
| DELETE\|POST | `/api/appointments/{id?}/delete` | `AppointmentController::destroy` | Sanctum + ownership | `Appointment_ID` or path | `status, message` | `appointments` | WORKING |
| GET | `/api/health/records` | `HealthController::getRecords` | Sanctum + scope | `Elderly_ID?` | `status, data[]` | `health_monitoring` | WORKING |
| POST | `/api/health/records` | `HealthController::storeRecord` | Sanctum + gate | `Heart_Rate, Blood_pressure, Oxyger, Temperature, steps, H_Type, H_Date, H_Result, Devices_ID, Emergency_ID, Elderly_ID?` | `status, message, data, generated_alert?` | `health_monitoring`, maybe `health_alerts` | WORKING |
| GET | `/api/health/alerts` | `HealthController::getAlerts` | Sanctum + scope | `Elderly_ID?` | `status, data[]` (+ healthRecord) | `health_alerts`, `health_monitoring` | WORKING |
| POST | `/api/health/alerts` | `HealthController::storeAlert` | Sanctum + record ownership / gate | `A_Type, A_Description, A_Level, A_Status, H_Record_ID?` | `status, message, data` (201) | `health_alerts` | WORKING |
| GET | `/api/emergency/logs` | `EmergencyController::getLogs` | Sanctum + scope | `Elderly_ID?` | `status, data[]` | `emergency_log` | WORKING |
| POST | `/api/emergency/logs` | `EmergencyController::storeLog` | Sanctum + gate | `E_Type, E_Location, latitude, Longitude, Descripion, Elderly_ID?` — **ignores client `E_State`** (hardcodes `نشط`) | `status, message, data` (201) | `emergency_log` | **PARTIAL** |
| PUT\|POST | `/api/emergency/logs/{id?}/status` | `EmergencyController::updateStatus` | Sanctum + ownership | `Emergency_ID`, `E_State`, `note`/`Descripion` | `status, message, data` | `emergency_log` | WORKING |
| GET | `/api/emergency/contacts` | `EmergencyController::getContacts` | Sanctum + scope | `Eldery_ID?` | `status, data[]` | `emergency_contacts` | WORKING |
| POST | `/api/emergency/contacts` | `EmergencyController::storeContact` | Sanctum + gate | `contact_Name, Phone_Number, Relationship, Priority, Eldery_ID?` | `status, message, data` (201) | `emergency_contacts` | WORKING |
| DELETE\|POST | `/api/emergency/contacts/{id?}/delete` | `EmergencyController::destroyContact` | Sanctum + ownership | `contact_ID` or path | `status, message` | `emergency_contacts` | WORKING |
| GET | `/api/devices` | `DeviceController::index` | Sanctum + scope | `Elderly_ID?` | `status, data[]` | `devices` | WORKING |
| POST | `/api/devices` | `DeviceController::store` | Sanctum + gate | `D_Type, T_Number, Elderly_ID?` | `status, message, data` (201) | `devices` | WORKING |
| DELETE\|POST | `/api/devices/{id?}/delete` | `DeviceController::destroy` | Sanctum + ownership | `Devices_ID` or path | `status, message` | `devices` | WORKING |
| GET | `/api/location/current` | `LocationController::current` | Sanctum + gate | `Elderly_ID?` | `status, data` (aliases `latitude`/`Longitude`) | `location_tracking` | WORKING |
| POST | `/api/location` | `LocationController::store` | Sanctum + gate | `L_Latitude`/`latitude`, `L_Longitude`/`Longitude`, `L_Scor`, `Elderly_ID?` | `status, message, data` (201) | `location_tracking` | WORKING |
| GET | `/api/location/history` | `LocationController::history` | Sanctum + gate | `Elderly_ID?` | `status, data[]` (limit 20) | `location_tracking` | WORKING |
| GET | `/api/location/safe-zones` | `LocationController::getSafeZones` | Sanctum + gate | `Elderly_ID?` | `status, data[]` | `safe_zones` (`Zldery_ID`) | WORKING (no Flutter client) |
| GET | `/api/notifications` | `NotificationController::index` | Sanctum; self CG/EL | optional filter ids (must match actor) | `status, data[]` | `notifications` | WORKING |
| POST | `/api/notifications` | `NotificationController::store` | Sanctum + link checks | `N_Title, N_Message, N_Type, Caregiver_ID?, Eldery_ID?` | `status, message, data` (201) | `notifications` | WORKING |
| GET | `/api/services` | `ServiceController::getServices` | Sanctum (catalog; no ownership) | — | `status, data[]` (aliases `Service_Name`, `Description`) | `services` | WORKING |
| POST | `/api/services/request` | `ServiceController::requestService` | Sanctum + gate | `Service_ID, Requst_Note, Elderly_ID?, Caregivers_id?` | `status, message, data` (201) | `services_request` | WORKING |
| GET | `/api/services/requests` | `ServiceController::getServiceRequests` | Sanctum; scoped | optional ids ignored for AuthZ (actor-scoped) | `status, data[]` | `services_request`, `services` | WORKING |
| GET | `/api/type-of-care` | `ServiceController::getTypeOfCare` | Sanctum + scope | `Eldery_ID?` | `status, data[]` | `type_of_care` | WORKING |
| POST | `/api/type-of-care` | `ServiceController::storeTypeOfCare` | Sanctum + gate | `Care_Type, Caregivers_ID?, Eldery_ID?` | `status, message, data` (201) | `type_of_care` | WORKING |
| POST | `/api/ai/voice-assistant` | `AiVoiceAssistantController::ask` | Sanctum + gate elderly | `prompt`/`query`/`message`, `elderly_id`/`Elderly_ID` | `status, reply?, is_emergency?, emergency_id?, message?` | Gemini + optionally `emergency_log`, patient context joins | **PARTIAL** (needs `GEMINI_API_KEY`; emergency keywords still work) |
| POST | `/api/voice-assistant/ask` | same | same | same | same | same | **PARTIAL** |
| GET\|POST | `/api/legacy` | `LegacyBridgeController::handle` | `legacy.auth` | `action` + payload | per action | per action | WORKING (dispatcher) |
| GET\|POST | `/api/bridge` | same | same | same | same | same | WORKING |

---

## 2. Legacy actions (`LegacyBridgeController`)

| Action | Controller method | AuthN | Class | Notes |
|--------|-------------------|-------|-------|-------|
| `ping` | inline | Public | WORKING | |
| `register_caregiver` | `AuthController::registerCaregiver` | Public | WORKING | |
| `login_caregiver` | `AuthController::loginCaregiver` | Public | WORKING | |
| `logout` | `AuthController::logout` | Sanctum | WORKING | |
| `me` / `auth_me` | `AuthController::me` | Sanctum | WORKING | Flutter uses `me` |
| `get_caregiver` | `CaregiverController::show` | Sanctum | WORKING | |
| `update_caregiver` | `CaregiverController::update` | Sanctum | WORKING | |
| `register_elderly` | `AuthController::registerElderly` | Public | WORKING | |
| `login_elderly` | `AuthController::loginElderly` | Public | WORKING | |
| `forgot_password` | `AuthController::forgotPassword` | Public | **MOCK ONLY** | No mail/reset; `role` unused |
| `get_elderly` | `ElderlyController::show` | Sanctum | WORKING | No ID → accessible list only |
| `update_elderly` | `ElderlyController::update` | Sanctum | WORKING | |
| `generate_linking_code` / `create_linking_code` | `ElderlyController::generateLinkingCode` | Sanctum (elderly) | WORKING | Flutter: `generate_linking_code` |
| `link_elderly` | `ElderlyController::linkCaregiver` | Sanctum (CG) | WORKING w/ code; **BROKEN** for direct-ID | |
| `get_medications` / `add_medication` / `update_medication` / `delete_medication` | MedicationController | Sanctum | WORKING | Typo PK `Medicayion_ID` shared by both sides |
| `get_appointments` / `add_appointment` / `delete_appointment` | AppointmentController | Sanctum | WORKING | No update appointment |
| `get_emergency_contacts` / `add_emergency_contact` / `delete_emergency_contact` | EmergencyController | Sanctum | WORKING | |
| `get_devices` / `add_device` / `delete_device` | DeviceController | Sanctum | WORKING | |
| `get_health_monitoring` / `add_health_record` | HealthController | Sanctum | WORKING | |
| `get_health_alerts` / `add_health_alert` | HealthController | Sanctum | WORKING | |
| `get_emergency_log` / `add_emergency_log` / `update_emergency_status` | EmergencyController | Sanctum | WORKING / PARTIAL (store ignores `E_State`) | |
| `get_location` / `update_location` / `get_location_history` | LocationController | Sanctum | WORKING | |
| `get_safe_zones` | `LocationController::getSafeZones` | Sanctum | WORKING backend; **NOT IMPLEMENTED** in Flutter ApiService | |
| `get_notifications` / `add_notification` | NotificationController | Sanctum | WORKING / PARTIAL (Flutter omits `Caregiver_ID` on add) | |
| `get_type_of_care` / `add_type_of_care` | ServiceController | Sanctum | WORKING | |
| `get_services` / `request_service` / `get_service_requests` | ServiceController | Sanctum | WORKING | |
| `voice_assistant` / `ask_ai` | `AiVoiceAssistantController::ask` | Sanctum | **PARTIAL** | Flutter: `voice_assistant` |
| *(unknown)* | — | Sanctum if not public | **NOT IMPLEMENTED** | HTTP 200 `{status:error, message: …غير معروف}` |

---

## 3. Flutter `ApiService` ↔ legacy action matrix

| Flutter method | Action sent | Backend handles? | Key parity | Class |
|----------------|-------------|------------------|------------|-------|
| `testConnection` / ping discovery | `ping` | Yes | — | WORKING |
| `registerCaregiver` | `register_caregiver` | Yes | Match | WORKING |
| `loginCaregiver` | `login_caregiver` | Yes | Match (`C_PhonNumber`+`C_Email` both set to phone) | WORKING |
| `getCaregiver` | `get_caregiver` | Yes | `Caregivers_ID` | WORKING |
| `updateCaregiver` | `update_caregiver` | Yes | Match name/phone/email/relationship; **no password** | WORKING (profile) / PARTIAL (no pwd change) |
| `registerElderly` | `register_elderly` | Yes | Match | WORKING |
| `loginElderly` | `login_elderly` | Yes | Match | WORKING |
| `forgotPassword` | `forgot_password` | Yes (stub) | Sends `email`,`role`; backend uses `email` only, ignores `role` | **MOCK ONLY** |
| `logoutRemote` | `logout` | Yes | — | WORKING |
| `fetchCurrentUser` | `me` | Yes | — | WORKING |
| `getElderlyList` | `get_elderly` | Yes | — | WORKING |
| `getElderly` | `get_elderly` | Yes | `Eldery_ID` | WORKING |
| `updateElderly` | `update_elderly` | Yes | Sends `E_Name,E_sex,E_PhonNumber` only — **no `E_Email`/`E_Password`** | **PARTIAL** |
| `generateLinkingCode` | `generate_linking_code` | Yes | — | WORKING |
| `linkElderly` | `link_elderly` | Yes | `Caregivers_ID` + `linking_code` | WORKING |
| `linkElderlyById` (deprecated) | `link_elderly` + `Eldery_ID` | Yes → **403** without code | Intentional block | **BROKEN** (by design) |
| `getMedications` | `get_medications` | Yes | `Elderly_ID` | WORKING |
| `addMedication` | `add_medication` | Yes | Match | WORKING |
| `updateMedication` | `update_medication` | Yes | Match | WORKING |
| `deleteMedication` | `delete_medication` | Yes | `Medicayion_ID` | WORKING |
| `getAppointments` | `get_appointments` | Yes | Match | WORKING |
| `addAppointment` | `add_appointment` | Yes | Match | WORKING |
| `deleteAppointment` | `delete_appointment` | Yes | Match | WORKING |
| `getEmergencyContacts` | `get_emergency_contacts` | Yes | `Eldery_ID` | WORKING |
| `addEmergencyContact` | `add_emergency_contact` | Yes | Match | WORKING |
| `deleteEmergencyContact` | `delete_emergency_contact` | Yes | `contact_ID` | WORKING |
| `getDevices` | `get_devices` | Yes | Match | WORKING |
| `addDevice` | `add_device` | Yes | `D_Type`,`T_Number`; unused Dart params `status` | WORKING |
| `deleteDevice` | `delete_device` | Yes | `Devices_ID` | WORKING |
| `getHealthRecords` | `get_health_monitoring` | Yes | Match | WORKING |
| `addHealthRecord` | `add_health_record` | Yes | Match (typo `Oxyger` shared) | WORKING |
| `getLocation` | `get_location` | Yes | Match | WORKING |
| `updateLocation` | `update_location` | Yes | `latitude`/`Longitude` OK; **`E_Location` ignored** by backend | **PARTIAL** |
| `getNotifications` | `get_notifications` | Yes | Match filters | WORKING |
| `addNotification` | `add_notification` | Yes | Sends `Eldery_ID`; **`caregiverId` param never sent as `Caregiver_ID`** | **PARTIAL** |
| `getEmergencyLog(s)` | `get_emergency_log` | Yes | Match | WORKING |
| `addEmergencyLog` | `add_emergency_log` | Yes | Sends `E_State` but store hardcodes `نشط` | **PARTIAL** |
| `updateEmergencyStatus` | `update_emergency_status` | Yes | Match (`Descripion` for note) | WORKING |
| `getTypeOfCare` | `get_type_of_care` | Yes | Match | WORKING |
| `addTypeOfCare` | `add_type_of_care` | Yes | Match | WORKING |
| `getLocationHistory` | `get_location_history` | Yes | Match | WORKING |
| `getServices` | `get_services` | Yes | Match | WORKING |
| `requestService` | `request_service` | Yes | Match (`Caregivers_id` typo shared) | WORKING |
| `getServiceRequests` | `get_service_requests` | Yes | Match | WORKING |
| `getHealthAlerts` | `get_health_alerts` | Yes | Match | WORKING |
| `addHealthAlert` | `add_health_alert` | Yes | Match | WORKING |
| `askAiVoiceAssistant` | `voice_assistant` | Yes | `prompt`,`elderly_id` | **PARTIAL** |
| — | `get_safe_zones` | Backend yes | No Flutter method | **NOT IMPLEMENTED** (client) |
| — | REST resource URLs | Backend yes | App never calls REST | DEFERRED / unused by Flutter |

---

## 4. Profile update field parity (Auth / Caregiver / Elderly)

### Caregiver

| Field | DB / Laravel update | Flutter `updateCaregiver` | Profile UI (`profile_page_caregiver.dart`) | Verdict |
|-------|---------------------|---------------------------|---------------------------------------------|---------|
| `C_Name` | Yes | Yes | Yes | OK |
| `C_PhonNumber` | Yes | Yes | Yes | OK |
| `C_Email` | Yes | Yes | Yes | OK |
| `C_Relationship` | Yes | Yes | Sent as existing `_relationship`; **UI edit dialog does not edit relationship** | PARTIAL |
| `C_Password` | Yes (hashed) | **Not exposed** | No password change | PARTIAL / gap |
| `Eldery_ID` | **Blocked** on update (use link) | Not sent | N/A | OK (security) |

### Elderly

| Field | DB / Laravel update | Flutter `updateElderly` | Profile UI (`profile_page_elderly.dart`) | Verdict |
|-------|---------------------|-------------------------|-------------------------------------------|---------|
| `E_Name` | Yes | Yes | Yes → `_persistElderlyData` | OK |
| `E_PhonNumber` | Yes | Yes | Yes | OK |
| `E_sex` | Yes | Yes | **Hardcoded `'ذكر'`** on persist; UI does not edit sex | **MISMATCH / PARTIAL** |
| `E_Email` | Yes | **Not in method signature / not sent** | Editable in UI locally; **never persisted to API** | **MISMATCH** |
| `E_Password` | Yes (elderly-self only) | Not sent | No UI | PARTIAL / gap |

`senior_manager.updateSenior` also calls `updateElderly` without email/password — same client gap.

### Auth register/login vs forms

Register/login keys align (`C_*` / `E_*`). Forgot-password UI sends `email` (+ unused `role`); backend stub matches surface contract only.

---

## 5. Flagged key / behavior mismatches

| Area | Flutter | Laravel | Impact |
|------|---------|---------|--------|
| Forgot password | Expects recovery UX; sends `role` | Stub success; no mail/token; ignores `role` | **MOCK ONLY** |
| Elderly email | UI edits `_email` | Accepts `E_Email` on update; client never sends | Email changes lost |
| Elderly sex on profile save | Always `'ذكر'` | Would store whatever sent | Overwrites real sex |
| Caregiver password change | None | Supported | Feature gap |
| Location update | Sends `E_Location` | Uses lat/lng only (`L_*`) | Location label unused |
| Emergency create | Sends `E_State` | Hardcoded `نشط` | Client state ignored |
| Add notification | `caregiverId` param unused | Accepts `Caregiver_ID` | CG targeting incomplete from client |
| Direct link | `linkElderlyById` | 403 without `linking_code` | Deprecated path fails (intended) |
| Safe zones | No ApiService | `get_safe_zones` + REST | Feature unused |
| Typos (shared) | `Medicayion_ID`, `Oxyger`, `Descripion`, `Caregivers_id`, `Eldery_ID` vs `Elderly_ID` | Same spellings | Working **if** both sides keep typos; mixed Eldery/Elderly resolved via `YusrAccess::resolveElderlyId` |

---

## 6. Classification summary

| Class | Count (approx) | Examples |
|-------|----------------|----------|
| WORKING | Majority of CRUD + auth + link-by-code | medications, appointments, login/register, me/logout |
| PARTIAL | Field/behavior incomplete | update elderly (email/sex), emergency store state, location `E_Location`, notifications CG id, voice (env key) |
| MOCK ONLY | 1 | `forgot_password` |
| BROKEN | 1 intentional | `linkElderlyById` / direct-ID link |
| NOT IMPLEMENTED | Client gaps | Flutter `get_safe_zones`; unknown legacy actions |
| DEFERRED | REST surface for Flutter | App stays on `/api/legacy` |

---

## 7. Sources

- `/agent/repos/Yusr/backend/routes/api.php`
- `/agent/repos/Yusr/backend/app/Http/Controllers/Api/*.php`
- `/agent/repos/Yusr/backend/app/Http/Middleware/AuthenticateLegacyActions.php`
- `/agent/repos/Yusr/backend/app/Support/YusrAccess.php`
- `/agent/repos/Yusr/lib/core/services/api_service.dart`
- `/agent/repos/Yusr/lib/pages/profile_page_caregiver.dart`
- `/agent/repos/Yusr/lib/pages/profile_page_elderly.dart`
- `/agent/repos/Yusr/lib/core/services/senior_manager.dart`
