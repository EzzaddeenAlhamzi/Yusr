---
cursor:
  subagentId: "bc-adbf1413-26f6-5643-8313-8a43e353fb2f"
---

# P1.4 — API Integration Matrix (Flutter ApiService × Legacy/REST × Laravel)

| Field | Value |
|-------|-------|
| Baseline | `9d930c6e3cedbf1f65b7d77afd0cf6a195f2093b` |
| Client transport | Prefer `*/api/legacy` on trusted origins (Bearer); Apache `yusr_api/index.php` gateway → Laravel |
| AuthN | Sanctum Bearer (`auth:sanctum` / `legacy.auth`) |
| Hard stops | No `:8000`/YOGC claim; no public API deploy; no secrets in reports |

**Status:** `WORKING` · `PARTIAL` · `BROKEN` · `MOCK ONLY` · `NOT IMPLEMENTED` · `DEFERRED`

---

## Auth

| Flutter method | Legacy action | REST | Controller | Req / response | DB | Status | Gap |
|----------------|---------------|------|------------|------------------|-----|--------|-----|
| `testConnection` | `ping` | `GET\|POST /api/ping` | closure | success + database | — | WORKING | |
| `registerCaregiver` | `register_caregiver` | `POST /api/auth/caregiver/register` | AuthController | C_* → token + caregiver + role | caregivers | WORKING | |
| `loginCaregiver` | `login_caregiver` | `POST /api/auth/caregiver/login` | AuthController | phone/email + password → token | caregivers | WORKING | fail-closed |
| `registerElderly` | `register_elderly` | `POST /api/auth/elderly/register` | AuthController | E_* → token + elderly + role | elderly | WORKING | |
| `loginElderly` | `login_elderly` | `POST /api/auth/elderly/login` | AuthController | phone/email + password → token | elderly | WORKING | |
| `forgotPassword` | `forgot_password` | `POST /api/auth/forgot-password` | AuthController::forgotPassword | email → success stub | caregivers/elderly lookup | PARTIAL | Stub: claims email sent; no mailer — **DEFERRED** real reset |
| `logoutRemote` | `logout` | `POST /api/auth/logout` | AuthController | revoke token | personal_access_tokens | WORKING | |
| `fetchCurrentUser` | `me` / `auth_me` | `GET\|POST /api/auth/me` | AuthController::me | role + safe profile | caregivers/elderly | WORKING | elderly→senior normalize |

---

## Profiles & linking

| Flutter method | Legacy action | REST | Controller | Request keys | Response | DB | Status | Gap |
|----------------|---------------|------|------------|--------------|----------|-----|--------|-----|
| `getCaregiver` | `get_caregiver` | `GET /api/caregiver/{id}` | CaregiverController::show | Caregivers_ID | `{status,data}` | caregivers | WORKING | |
| `updateCaregiver` | `update_caregiver` | `PUT\|POST /api/caregiver/{id?}` | CaregiverController::update | C_Name, C_PhonNumber, C_Email, C_Relationship | success + data | caregivers | WORKING | UI may ignore failure |
| `getElderly` / `getElderlyList` | `get_elderly` | `GET /api/elderly/{id}` | ElderlyController::show | Eldery_ID optional | data object or accessible list | elderly (+caregiver nest for self) | WORKING | |
| `updateElderly` | `update_elderly` | `PUT\|POST /api/elderly/{id?}` | ElderlyController::update | E_Name, E_sex, E_PhonNumber, E_Email? | success | elderly | PARTIAL | Client often omits E_Email; UI hardcodes E_sex |
| `generateLinkingCode` | `generate_linking_code` | `POST /api/elderly/linking-code` | ElderlyController | (self elderly) | code + expires | elderly_linking_codes | WORKING | |
| `linkElderly` | `link_elderly` | `POST /api/elderly/link` | ElderlyController | Caregivers_ID + linking_code | caregiver + elderly | caregivers.Eldery_ID | WORKING | |
| `linkElderlyById` (deprecated) | `link_elderly` | same | same | Eldery_ID only | 403 | — | WORKING (blocked) | |

---

## Domain resources (existing workflows)

| Flutter method | Legacy action | REST | Status | Gap |
|----------------|---------------|------|--------|-----|
| `get/add/update/deleteMedication` | `*_medication(s)` | `/api/medications*` | WORKING | List helpers return `[]` on error |
| `get/add/deleteAppointment` | `*_appointment(s)` | `/api/appointments*` | WORKING | same |
| `get/add/deleteEmergencyContact` | `*_emergency_contact(s)` | `/api/emergency/contacts*` | WORKING | |
| `get/add/deleteDevice` | `*_device(s)` | `/api/devices*` | WORKING | |
| `getHealthRecords` / `addHealthRecord` | `get_health_monitoring` / `add_health_record` | `/api/health/records*` | WORKING | |
| `get/addHealthAlert` | `*_health_alert(s)` | `/api/health/alerts*` | WORKING | |
| `getLocation` / `updateLocation` / `getLocationHistory` | location* | `/api/location*` | WORKING | |
| `get/addNotification` | notifications* | `/api/notifications*` | WORKING | |
| `get/addEmergencyLog` / `updateEmergencyStatus` | emergency_log* | `/api/emergency/logs*` | WORKING | |
| `get/addTypeOfCare` | type_of_care* | `/api/type-of-care*` | WORKING | |
| `getServices` / `requestService` / `getServiceRequests` | services* | `/api/services*` | WORKING | catalog requires auth |
| `askAiVoiceAssistant` | `voice_assistant` | `/api/ai/voice-assistant` | PARTIAL | Gemini key / voice — do not expand in P1.4 |

---

## Compatibility notes (Unit I)

| Topic | Finding | Action in P1.4 |
|-------|---------|----------------|
| Legacy bridge coverage | All ApiService actions mapped in LegacyBridgeController | Preserve |
| Bearer trust | `:8000` never attaches Bearer | Preserve |
| List empty vs error | Many getters return `[]` when `status != success` | Expose error signal / `lastError` honesty for callers |
| Med next-task time | SeniorManager reads `M_Time` (absent); DB has `M_RepatTime` | Fix field name |
| Forgot password | Stub success message | Do not invent mail; optional clearer `error_type`/message honesty without breaking enum contract |
| Age / blood / biometric | No DB columns | DEFERRED — do not invent schema |
| Caregiver nest on elderly show | Only when actor is that elderly | By design; CG uses getCaregiver / link |

---

## AuthZ reminder (unchanged)

Ownership via `YusrAccess` + policies (P1.2). P1.4 must not weaken AuthN/AuthZ. SEC-001…005 remain OPEN.
