---
cursor:
  subagentId: "bc-adbf1413-26f6-5643-8313-8a43e353fb2f"
---

# P1.4 — Functionality Matrix (Flutter UI × API)

| Field | Value |
|-------|-------|
| Gate | **P1.4** — FAST incremental API integration & UI functionality |
| Baseline | `origin/main` @ `9d930c6e3cedbf1f65b7d77afd0cf6a195f2093b` (verified) |
| Branch | `cursor/p1.4-api-integration-fb2f` |
| Inventory date (UTC) | 2026-11-19 |
| Scope | Existing screens/workflows only — **not** P2/P3/P4 feature build-out |
| Out of scope | YUSR-SEC-001…005; PR #6 Arabic voice; EMA/A8/A9/ZIP; public deploy |

**Status legend:** `WORKING` · `PARTIAL` · `BROKEN` · `MOCK ONLY` · `NOT IMPLEMENTED` · `DEFERRED TO FUTURE PHASE`

---

## Public / bootstrap

| Screen / route | Role | UI elements / actions | Expected action | API | Status | Notes |
|----------------|------|----------------------|-----------------|-----|--------|-------|
| `/` SessionBootstrapPage | public | loading + retry | restore via token + `/me` | `action=me` | WORKING | P1.3 |
| `/welcome` WelcomePage | public | CTA → onboarding / login | navigate | none | WORKING | |
| `/onboarding` (+ screen2/3) | public | continue / skip / have account | navigate login/register | none | WORKING | |
| `/who-are-you` | public | caregiver / senior | choose role → login or choose-mode | none | WORKING | |
| `/choose-mode` | senior (or pre-login) | simple/advanced + continue | persist per-user mode keys; route home | SharedPreferences only | WORKING | A4-safe keys |
| `/login` LoginPage | public | phone/password, forgot, register link | login CG/elderly; errors Arabic | `login_*`, `forgot_password` | WORKING (forgot stub honest) | Login/logout WORKING; forgot no longer claims email sent |
| `/register` RegisterPage | public | name/phone/email/password/gender | register + session + route | `register_*` | WORKING | |

---

## Caregiver flow

| Screen / route | Role | UI elements / actions | Expected action | API | Status | Notes |
|----------------|------|----------------------|-----------------|-----|--------|-------|
| `/main-caregiver` | caregiver | drawer, refresh, status card, action grid, link CTA | show linked elderly + real next task/device | `get_elderly`, `get_devices`, `get_medications`, `get_appointments` via SeniorManager | WORKING (honest unknowns) | P1.4: no fake battery/health/pairing; uses `M_RepatTime` |
| `/link-senior` | caregiver | 6-digit code submit | link via code; update session | `link_elderly` | WORKING | Direct-ID blocked server-side |
| `/profile` ProfilePageCaregiver | caregiver | tabs: main/account/settings; edit; logout; share | load/update CG; logout revoke | `get_caregiver`, `update_caregiver`, `logout` | WORKING (settings local) | P1.4: save after success; share clipboard honesty; prefs persisted; help/privacy deferred snackbars |
| `/medicines` | caregiver | list/add/edit/delete | CRUD meds for linked elderly | medications* | WORKING | empty list on API error = silent fail (H) |
| `/appointments` | caregiver | list/add/delete | CRUD appts | appointments* | WORKING | same empty-on-error |
| `/location` | caregiver | current + history + notifs | load location data | location*, notifications | WORKING | |
| `/health-status` | caregiver | records + alerts | load health | health* | WORKING | |
| `/senior-data` | caregiver | type of care add/list | load/add care type | type_of_care* | WORKING | |
| `/activity-log` | caregiver | devices + health + add record | aggregate activity | devices + health | WORKING | |
| `/devices` | caregiver | add/delete devices + server config | device CRUD | devices* | WORKING | |
| `/emergency` | caregiver | logs + update status | emergency log management | emergency* | WORKING | |
| `/notifications` | caregiver | refresh list | list notifications | `get_notifications` | WORKING | |
| `/services` | caregiver | catalog + request | list/request services | services* | WORKING | |
| Drawer CustomAppDrawer | caregiver | nav tiles + logout | navigate / logout honesty | logout | WORKING | |

---

## Elderly / senior flow (advanced)

| Screen / route | Role | UI elements / actions | Expected action | API | Status | Notes |
|----------------|------|----------------------|-----------------|-----|--------|-------|
| `/home-elderly` HomePage | senior | welcome name, SOS grid, notifications dialog, status card | real name + real notifs + status | Auth + `get_notifications` + health/emergency | WORKING | P1.4: notifs + `_TodayStatusCard` from API (no fake “كل الامور جيدة”) |
| `/dates` DatesScreen | senior | list/add/delete/edit | CRUD appts | get/add/delete appointments | WORKING (edit deferred) | P1.4: add via AddDate API; delete checks status; edit honest (no UPDATE route) |
| `/add-date` AddDateScreen | senior | save appointment | persist to API | `add_appointment` | WORKING | Was BROKEN (local-only); now API before success |
| `/past-dates` PastDatesScreen | senior | past list/delete | past from API | get/delete appointments | WORKING | Was MOCK ONLY hardcoded list |
| `/profile-elderly` | senior | edit name/phone/age/blood/emergency/caregiver; logout | persist elderly + contacts | `get_elderly`, `update_elderly`, emergency contacts | WORKING (age/blood local) | P1.4: sex/email persist; API status checked; CG display-only; age/blood deferred schema |
| `/senior-link-code` | senior | generate/refresh code | show temp code | `generate_linking_code`, `get_elderly` | WORKING | |
| `/senior-link-success` | senior | success UI | confirm link | none (nav) | WORKING | |
| `/medicines-elderly`, `/add-medicine` | senior | med CRUD | API meds | medications* | WORKING | |
| `/dates`, `/add-date`, `/past-dates` | senior | appt CRUD | API appts | appointments* | WORKING | |
| `/location-elderly`, `/senior-location` | senior | GPS + DB fallback | update/get location | location* | PARTIAL | GPS path + silent catch fallback |
| `/emergency-elderly` | senior | SOS log + contacts | add log/contact | emergency* | WORKING | SOS preserved |
| `/health` | senior | health records | list | health* | WORKING | |
| `/devices-elderly` | senior | devices | CRUD | devices* | WORKING | |
| `/caregiver-contact` | senior | show linked CG | load elderly (+caregiver nest) | `get_elderly` | WORKING | caregiver nest only on elderly self-view |
| `/return-home` | senior | navigate home / share loc | update location | `get_elderly`, `update_location` | PARTIAL | silent catches |
| `/ai` | senior | prompt → answer | voice assistant | `voice_assistant` | PARTIAL | needs Gemini key; honest error if unavailable — **PR #6 voice out of scope**; keep as-is |
| `/senior-help` | senior | help content | static/help | none | DEFERRED TO FUTURE PHASE | content/help center |
| `/senior-notifications` | senior | notifications UI | list | check page | PARTIAL | verify API wire in impl |

---

## Elderly simple mode

| Screen / route | Role | UI elements / actions | Expected action | API | Status | Notes |
|----------------|------|----------------------|-----------------|-----|--------|-------|
| `/simple-home` | senior | SOS grid, header | navigate + SOS | none for tiles; overflow fixed P1.2 | WORKING | preserve SOS/RTL/overflow |
| `/simple-contacts` | senior | contact list | emergency contacts | `get_emergency_contacts` | WORKING | |
| `/simple-medicines` | senior | med list | meds | `get_medications` | WORKING | |
| `/simple-return-home` | senior | home address | get elderly | `get_elderly` | WORKING | |

---

## Cross-cutting UI defects (P1.4 units)

| ID | Area | Defect | Unit | Classification |
|----|------|--------|------|----------------|
| F-01 | Auth forgot | Server stub returns success "email sent"; UI treats as real | A | PARTIAL — keep stub honesty (no invent mail); clarify message if touched |
| F-02 | Elderly update | `updateElderly` always sends `sex: 'ذكر'` | B | BROKEN field |
| F-03 | Elderly profile | Caregiver name/phone edit shows success without API | B/D | BROKEN honesty |
| F-04 | Elderly profile | Emergency contact edit may not call `add/update` API | B | PARTIAL |
| F-05 | CG profile | Optimistic UI before `update_caregiver` success | C | PARTIAL |
| F-06 | CG profile | Share copies nothing | G | MOCK ONLY (button) |
| F-07 | CG settings | Notif/biometric/language not persisted; help/privacy dead | F/G | PARTIAL / NOT IMPLEMENTED |
| F-08 | SeniorManager | Fake battery 85, health مستقر, doctor/hospital, pairing `YS-id`, `M_Time` | D/E | MOCK ONLY fields |
| F-09 | Home elderly | Notifications dialog hardcoded empty | E | PARTIAL |
| F-10 | ApiService lists | Error → `[]` (looks like empty success) | H/I | PARTIAL honesty |
| F-11 | Many pages | `catch (_) {}` swallows load/save errors | H | PARTIAL |
| F-12 | Age/blood/biometric HW | No backend columns / no biometric stack | F | DEFERRED TO FUTURE PHASE |
| F-13 | AI / voice | Gemini + Arabic voice prototype | — | DEFERRED / PR #6 — **do not touch** |
| F-14 | SEC-001…005 | Public dump / db.php / legacy backup | — | OPEN out of scope |

---

## Explicit non-defects (do not treat as P1.4 bugs)

- P2/P3/P4 product features not present in UI
- Arabic voice track (PR #6)
- Full password-reset email delivery (known stub since P1.1)
- Production AuthZ hardening beyond lab (P1.2 conditions)
- Redesign / removal of SOS, RTL, overflow fixes
